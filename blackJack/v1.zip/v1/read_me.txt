Instructions to run the program

Blackjack.java is the main file

in terminal 
-compile the program

javac Blackjack.java

-then to run it 

java Blackjack

the rest of instructions will be in terminal ones its running 

